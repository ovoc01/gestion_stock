package com.colasmadagascar.stockinventory.entity;

import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Column;
import jakarta.persistence.Table;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.FetchType;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import java.sql.Timestamp;

@Entity
@Table(name="utilisateur")

public class Utilisateur  {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    
    Long usrId;

    @Column
    String usrLogin;
    @Column
    String usrPwd;
    @Column
    String usrNom;
    @Column
    String usrPrenom;
    @Column
    Timestamp usrDtDernAcc;
    @Column
    Timestamp usrDtCr;

    

    
    public void setUsrId(Long usrId){
        this.usrId = usrId;
    }

    public Long getUsrId(){
        return this.usrId;
    }


    public void setUsrLogin(String usrLogin){
        this.usrLogin = usrLogin;
    }

    public String getUsrLogin(){
        return this.usrLogin;
    }


    public void setUsrPwd(String usrPwd){
        this.usrPwd = usrPwd;
    }

    public String getUsrPwd(){
        return this.usrPwd;
    }


    public void setUsrNom(String usrNom){
        this.usrNom = usrNom;
    }

    public String getUsrNom(){
        return this.usrNom;
    }


    public void setUsrPrenom(String usrPrenom){
        this.usrPrenom = usrPrenom;
    }

    public String getUsrPrenom(){
        return this.usrPrenom;
    }


    public void setUsrDtDernAcc(Timestamp usrDtDernAcc){
        this.usrDtDernAcc = usrDtDernAcc;
    }

    public Timestamp getUsrDtDernAcc(){
        return this.usrDtDernAcc;
    }


    public void setUsrDtCr(Timestamp usrDtCr){
        this.usrDtCr = usrDtCr;
    }

    public Timestamp getUsrDtCr(){
        return this.usrDtCr;
    }


    public void setRole(Role role){
        this.role = role;
    }

    public Role getRole(){
        return this.role;
    }



}
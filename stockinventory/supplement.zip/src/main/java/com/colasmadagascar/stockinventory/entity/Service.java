package com.colasmadagascar.stockinventory.entity;

import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Column;
import jakarta.persistence.Table;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.FetchType;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import java.sql.Timestamp;

@Entity
@Table(name="service")

public class Service  {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    
    Long serviceId;

    @Column
    String serviceLi;
    @Column
    Integer serviceNumBu;
    @Column
    Timestamp serviceDtCr;
    @Column
    Timestamp serviceDernMdf;

    

    
    public void setServiceId(Long serviceId){
        this.serviceId = serviceId;
    }

    public Long getServiceId(){
        return this.serviceId;
    }


    public void setServiceLi(String serviceLi){
        this.serviceLi = serviceLi;
    }

    public String getServiceLi(){
        return this.serviceLi;
    }


    public void setServiceNumBu(Integer serviceNumBu){
        this.serviceNumBu = serviceNumBu;
    }

    public Integer getServiceNumBu(){
        return this.serviceNumBu;
    }


    public void setServiceDtCr(Timestamp serviceDtCr){
        this.serviceDtCr = serviceDtCr;
    }

    public Timestamp getServiceDtCr(){
        return this.serviceDtCr;
    }


    public void setServiceDernMdf(Timestamp serviceDernMdf){
        this.serviceDernMdf = serviceDernMdf;
    }

    public Timestamp getServiceDernMdf(){
        return this.serviceDernMdf;
    }



}
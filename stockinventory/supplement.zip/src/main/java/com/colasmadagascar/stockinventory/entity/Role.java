package com.colasmadagascar.stockinventory.entity;

import java.util.List;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Column;
import jakarta.persistence.Table;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.FetchType;
import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity
@Table(name="role")

public class Role  {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    
    Long roleId;

    @Column
    String roleLi;

    

    
    public void setRoleId(Long roleId){
        this.roleId = roleId;
    }

    public Long getRoleId(){
        return this.roleId;
    }


    public void setRoleLi(String roleLi){
        this.roleLi = roleLi;
    }

    public String getRoleLi(){
        return this.roleLi;
    }



}
package com.colasmadagascar.stockinventory.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import java.util.List;
import org.springframework.web.bind.annotation.CrossOrigin;
import com.colasmadagascar.stockinventory.entity.Service;
import com.colasmadagascar.stockinventory.service.ServiceService;

@RestController
@RequestMapping("/services")
@CrossOrigin("*")

public class ServiceController  {
    @Autowired  ServiceService serviceService;
    
    @GetMapping
    public ResponseEntity<Object> getAllService() {
        HashMap<String,Object> data = new HashMap<>();
        try{
            List<Service>services =  serviceService.getAllEntities();
            data.put("services",services);
            return new ResponseEntity<>(data, HttpStatus.OK);
        }catch(Exception e){
            data.put("error",e.getMessage());
            return ResponseEntity.badRequest().body(data);
        }

    }

    @GetMapping("/{id}")
    public ResponseEntity<Object> findByIdService(@PathVariable("id")Long id){
        HashMap<String,Object> data = new HashMap<>();

        try{
            Service service = serviceService.getEntityById(id).get();
            data.put("service",service);
            return new ResponseEntity<>(data, HttpStatus.OK);
        }catch(Exception e){
            data.put("error",e.getMessage());
            return ResponseEntity.badRequest().body(data);
        }
    }


    @PostMapping
    public ResponseEntity<Object> createService(@RequestBody Service service){
        HashMap<String,Object> data = new HashMap<>();
        try{
            serviceService.saveEntity(service);
            data.put("message","Service created successfully");
            return new ResponseEntity<>(data, HttpStatus.CREATED);
        }catch(Exception e){
            data.put("error",e.getMessage());
            return ResponseEntity.badRequest().body(data);
        }
    }


    @PutMapping("/{id}")
    public ResponseEntity<Object> updateService(@PathVariable("id")Long id){
        HashMap<String,Object> data = new HashMap<>();

        try{
            //TODO
            return ResponseEntity.ok("success");
        }catch(Exception e){
            data.put("error",e.getMessage());
            return ResponseEntity.badRequest().body(data);
        }
    }




}
package com.colasmadagascar.stockinventory.service;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageRequest;
import com.colasmadagascar.stockinventory.entity.Service;
import com.colasmadagascar.stockinventory.repository.ServiceRepository;

@Service

public class ServiceService  {
   @Autowired
   ServiceRepository serviceRepository;

   
   public List<Service> getAllEntities(int page,int size) {
        Pageable pageable = PageRequest.of(page-1, size);
        return serviceRepository.findAll(pageable).toList();
    }


    public Optional<Service> getEntityById(Long id) {
        return serviceRepository.findById(id);
    }


    public Service saveEntity(Service service) {
        return serviceRepository.save(service);
    }


    public Service updateEntity(Service service) {
        return serviceRepository.save(service);
    }

    public void deleteEntityById(Long id) {
        serviceRepository.deleteById(id);
    }

    public long count(){
        return serviceRepository.count();
    }



}